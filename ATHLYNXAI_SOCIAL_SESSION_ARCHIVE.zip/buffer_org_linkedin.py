"""
Check org info (without plan field) and test LinkedIn channel via Buffer
"""
import requests
import json

BUFFER_TOKEN = "kB3LprBJtIH1-1F1v_DQcjOIRFdX13YFQVPXrpz9gD_"
ORG_ID = "69e5eb4fa8900ccfe436f53a"

# Check organization info without plan
print("=== Organization Info ===")
org_query = f"""
query {{
  organization(id: "{ORG_ID}") {{
    id
    name
    isOneBufferOrganization
  }}
}}
"""
r = requests.post(
    "https://api.buffer.com/graphql",
    headers={"Authorization": f"Bearer {BUFFER_TOKEN}", "Content-Type": "application/json"},
    json={"query": org_query},
    timeout=30,
)
print(json.dumps(r.json(), indent=2))

# Test LinkedIn channel via Buffer (it's in the channel list)
print("\n=== Testing LinkedIn via Buffer ===")
linkedin_channel = "69e6cd3f031bfa423c264c63"
test_text = "🏆 ATHLYNX.AI — The #1 AI Platform for Athletes & NIL Deals.\\n\\nYour career. Your brand. Your future — all in one place.\\n\\nhttps://athlynx.ai\\n\\n#ATHLYNX #NIL #SportsAI #AthleteMarketing"

mutation = f'''
mutation {{
  createPost(input: {{
    channelId: "{linkedin_channel}"
    text: "{test_text}"
    schedulingType: automatic
    mode: shareNow
  }}) {{
    __typename
  }}
}}
'''
r2 = requests.post(
    "https://api.buffer.com/graphql",
    headers={"Authorization": f"Bearer {BUFFER_TOKEN}", "Content-Type": "application/json"},
    json={"query": mutation},
    timeout=30,
)
result = r2.json()
typename = result.get("data", {}).get("createPost", {}).get("__typename", "")
print(f"LinkedIn via Buffer: __typename = {typename}")
print(json.dumps(result, indent=2))

# Test YouTube channel via Buffer
print("\n=== Testing YouTube via Buffer ===")
youtube_channel = "69e6cd7c031bfa423c264dd5"
mutation_yt = f'''
mutation {{
  createPost(input: {{
    channelId: "{youtube_channel}"
    text: "{test_text}"
    schedulingType: automatic
    mode: shareNow
  }}) {{
    __typename
  }}
}}
'''
r3 = requests.post(
    "https://api.buffer.com/graphql",
    headers={"Authorization": f"Bearer {BUFFER_TOKEN}", "Content-Type": "application/json"},
    json={"query": mutation_yt},
    timeout=30,
)
result3 = r3.json()
typename3 = result3.get("data", {}).get("createPost", {}).get("__typename", "")
print(f"YouTube via Buffer: __typename = {typename3}")
print(json.dumps(result3, indent=2))
