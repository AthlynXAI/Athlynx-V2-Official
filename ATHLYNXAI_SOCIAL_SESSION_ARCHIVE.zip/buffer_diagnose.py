"""
Diagnose Buffer UnexpectedError on individual channels
"""
import requests
import json

BUFFER_TOKEN = "kB3LprBJtIH1-1F1v_DQcjOIRFdX13YFQVPXrpz9gD_"

failing_channels = [
    {"id": "69f29ddf5c4c051afaf3e12e", "name": "Facebook/Athlynx", "service": "facebook"},
    {"id": "69e6cca6031bfa423c26478e", "name": "Instagram/chad_dozier", "service": "instagram"},
    {"id": "69e6ce77031bfa423c265389", "name": "Instagram/chaddozier14", "service": "instagram"},
    {"id": "69f3f06f5c4c051afaf9eeb7", "name": "Facebook/Chad", "service": "facebook"},
    {"id": "69e6cdf3031bfa423c2650a8", "name": "Google Business", "service": "googlebusiness"},
]

# Try a very short, simple post text to rule out content issues
test_text = "🏆 ATHLYNX.AI — The #1 AI Platform for Athletes & NIL Deals. https://athlynx.ai #ATHLYNX #NIL"
escaped = test_text.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n')

for ch in failing_channels:
    mutation = f'''
    mutation {{
      createPost(input: {{
        channelId: "{ch["id"]}"
        text: "{escaped}"
        schedulingType: automatic
        mode: shareNow
      }}) {{
        __typename
      }}
    }}
    '''
    r = requests.post(
        "https://api.buffer.com/graphql",
        headers={
            "Authorization": f"Bearer {BUFFER_TOKEN}",
            "Content-Type": "application/json",
        },
        json={"query": mutation},
        timeout=30,
    )
    result = r.json()
    typename = result.get("data", {}).get("createPost", {}).get("__typename", "")
    print(f"\n[{ch['name']}] ({ch['service']})")
    print(f"  HTTP Status: {r.status_code}")
    print(f"  __typename: {typename}")
    print(f"  Full response: {json.dumps(result)}")
