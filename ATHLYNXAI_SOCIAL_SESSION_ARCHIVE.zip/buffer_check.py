"""
Check Buffer channel status and diagnose UnexpectedError
"""
import requests
import json

BUFFER_TOKEN = "kB3LprBJtIH1-1F1v_DQcjOIRFdX13YFQVPXrpz9gD_"
ORG_ID = "69e5eb4fa8900ccfe436f53a"

# Query channels with required input
channels_query = f"""
query {{
  channels(input: {{ organizationId: "{ORG_ID}" }}) {{
    id
    name
    service
    serviceId
    isLocked
    isDisconnected
  }}
}}
"""

response = requests.post(
    "https://api.buffer.com/graphql",
    headers={
        "Authorization": f"Bearer {BUFFER_TOKEN}",
        "Content-Type": "application/json",
    },
    json={"query": channels_query},
    timeout=30,
)

result = response.json()
print("Buffer Channel Status:")
print(json.dumps(result, indent=2))

# Also try a simple test post to one channel to see full error
print("\n--- Testing single post to Facebook/Athlynx ---")
test_channel = "69f29ddf5c4c051afaf3e12e"
test_text = "Test post from ATHLYNX AI"
escaped = test_text.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n')

mutation = f'''
mutation {{
  createPost(input: {{
    channelId: "{test_channel}"
    text: "{escaped}"
    schedulingType: automatic
    mode: shareNow
  }}) {{
    __typename
    ... on PostActionSuccess {{
      post {{
        id
        status
      }}
    }}
    ... on PostError {{
      type
      message
    }}
  }}
}}
'''

r2 = requests.post(
    "https://api.buffer.com/graphql",
    headers={
        "Authorization": f"Bearer {BUFFER_TOKEN}",
        "Content-Type": "application/json",
    },
    json={"query": mutation},
    timeout=30,
)
print(json.dumps(r2.json(), indent=2))
