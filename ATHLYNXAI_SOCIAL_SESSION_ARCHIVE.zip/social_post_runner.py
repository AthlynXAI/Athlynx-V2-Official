"""
ATHLYNX Social Post Runner
Replicates the exact rotation logic from server/jobs/socialPostCron.ts
Runs the scheduled post for today's date/time slot across all channels.
"""

import requests
import json
import math
from datetime import datetime, timezone

# ─────────────────────────────────────────────
# CREDENTIALS (from Master Reference)
# ─────────────────────────────────────────────
BUFFER_TOKEN = "kB3LprBJtIH1-1F1v_DQcjOIRFdX13YFQVPXrpz9gD_"
BASE_URL = "https://athlynx.ai"

# Buffer channel IDs — ALL 10 channels
BUFFER_CHANNELS = {
    "instagram_chad_dozier":  "69e6cca6031bfa423c26478e",
    "linkedin":               "69e6cd3f031bfa423c264c63",
    "youtube":                "69e6cd7c031bfa423c264dd5",
    "tiktok_chad":            "69e6cd99031bfa423c264e8c",  # video only
    "google_business":        "69e6cdf3031bfa423c2650a8",
    "twitter":                "69e6ce05031bfa423c265121",
    "tiktok_cdozier75":       "69e6ce56031bfa423c2652c8",  # video only
    "instagram_chaddozier14": "69e6ce77031bfa423c265389",
    "facebook_athlynx":       "69f29ddf5c4c051afaf3e12e",
    "facebook_chad":          "69f3f06f5c4c051afaf9eeb7",
}

# Text-capable channels in posting order (TikTok excluded — requires video)
TEXT_CHANNELS_ORDERED = [
    {"id": BUFFER_CHANNELS["facebook_athlynx"],       "offset": 0, "name": "Facebook/Athlynx"},
    {"id": BUFFER_CHANNELS["instagram_chad_dozier"],  "offset": 1, "name": "Instagram/chad_dozier"},
    {"id": BUFFER_CHANNELS["twitter"],                "offset": 2, "name": "X/Twitter"},
    {"id": BUFFER_CHANNELS["instagram_chaddozier14"], "offset": 3, "name": "Instagram/chaddozier14"},
    {"id": BUFFER_CHANNELS["facebook_chad"],          "offset": 4, "name": "Facebook/Chad"},
    {"id": BUFFER_CHANNELS["google_business"],        "offset": 5, "name": "Google Business"},
]

# ─────────────────────────────────────────────
# IMAGE LIBRARY — 20 unique images
# ─────────────────────────────────────────────
IMAGE_LIBRARY = [
    f"{BASE_URL}/brand/athlynx-promo.png",
    f"{BASE_URL}/brand/athlynx-logo-main.png",
    f"{BASE_URL}/brand/athlynx-investor.png",
    f"{BASE_URL}/brand/app-screen-2.png",
    f"{BASE_URL}/brand/app-screen-5.png",
    f"{BASE_URL}/brand/app-screen-9.png",
    f"{BASE_URL}/brand/app-screen-12.png",
    f"{BASE_URL}/brand/app-screen-15.png",
    f"{BASE_URL}/brand/app-screen-18.png",
    f"{BASE_URL}/brand/dhg-empire-hero.png",
    f"{BASE_URL}/images/athlete-focus.jpg",
    f"{BASE_URL}/images/champion-hero.jpg",
    f"{BASE_URL}/athlete-football.jpg",
    f"{BASE_URL}/athlete-basketball.jpg",
    f"{BASE_URL}/athlete-baseball.jpg",
    f"{BASE_URL}/athlete-track.jpg",
    f"{BASE_URL}/athlete-training.jpg",
    f"{BASE_URL}/athlynx-og-social.png",
    f"{BASE_URL}/economic-vision.png",
    f"{BASE_URL}/professional-athlete-dashboard.png",
]

# ─────────────────────────────────────────────
# POST LIBRARY — 30 unique text posts
# ─────────────────────────────────────────────
POST_LIBRARY = [
    {"text": "🏆 ATHLYNX.AI — The #1 AI Platform for Athletes & NIL Deals.\n\nYour career. Your brand. Your future — all in one place.\n\n✅ AI-powered NIL marketplace\n✅ Real-time recruiting analytics\n✅ 20+ integrated platforms\n\nhttps://athlynx.ai\n\n#ATHLYNX #NIL #SportsAI #AthleteMarketing", "link": "https://athlynx.ai"},
    {"text": "⚡ ONE PLATFORM. EVERY EDGE.\n\nATHLYNX gives athletes the tools to get recruited, get paid, and get ahead.\n\n🎯 NIL deals\n🎯 Transfer portal analytics\n🎯 AI coaching insights\n\nhttps://athlynx.ai\n\n#ATHLYNX #CollegiateAthletes #NIL #RecruitingEdge", "link": "https://athlynx.ai"},
    {"text": "💎 THE DIAMOND GRIND IS REAL.\n\nBaseball athletes — ATHLYNX tracks your stats, connects you to scouts, and finds your NIL deals.\n\nYour next level starts here 👉 https://athlynx.ai\n\n#ATHLYNX #BaseballRecruiting #NIL #CollegiateBaseball", "link": "https://athlynx.ai"},
    {"text": "🤖 YOUR AI COACH NEVER SLEEPS.\n\nWhile you rest, ATHLYNX is analyzing your performance, finding opportunities, and building your brand.\n\n24/7 AI-powered athlete management 👉 https://athlynx.ai\n\n#ATHLYNX #AICoach #SportsAI #AthletePerformance", "link": "https://athlynx.ai"},
    {"text": "🏈 FOOTBALL ATHLETES — YOUR NIL ERA IS NOW.\n\nATHLYNX connects you directly to brands, boosters, and NIL deals.\n\nNo agents. No middlemen. Just results.\n\nhttps://athlynx.ai\n\n#ATHLYNX #FootballNIL #NILDeals #CollegiateFootball", "link": "https://athlynx.ai"},
    {"text": "🏀 BASKETBALL PLAYERS — LEVEL UP YOUR RECRUITING.\n\nATHLYNX gives you real-time analytics, NIL opportunities, and a global athlete network.\n\nJoin the movement 👉 https://athlynx.ai\n\n#ATHLYNX #BasketballRecruiting #NIL #HoopsDreams", "link": "https://athlynx.ai"},
    {"text": "🌍 ATHLETES CONNECT GLOBALLY ON ATHLYNX.\n\nShare schedules. Compare recruiting efforts. Build your brand worldwide.\n\nThe Athlete Playbook starts here 👉 https://athlynx.ai\n\n#ATHLYNX #GlobalAthletes #AthletePlaybook #NIL", "link": "https://athlynx.ai"},
    {"text": "🚀 FROM UNRECRUITED TO UNSTOPPABLE.\n\nATHLYNX's Transfer Portal analytics help athletes at smaller schools get seen, get recruited, and increase their NIL value.\n\nhttps://athlynx.ai\n\n#ATHLYNX #TransferPortal #NIL #CollegiateAthletes", "link": "https://athlynx.ai"},
    {"text": "💰 YOUR NAME. YOUR IMAGE. YOUR LIKENESS. YOUR MONEY.\n\nATHLYNX's AI-powered NIL marketplace connects athletes with brands that want to pay them.\n\nStart earning 👉 https://athlynx.ai\n\n#ATHLYNX #NILMarketplace #AthleteMarketing #GetPaid", "link": "https://athlynx.ai"},
    {"text": "📊 DATA-DRIVEN RECRUITING.\n\nATHLYNX gives coaches and athletes real-time analytics to make smarter recruiting decisions.\n\n20+ integrated platforms. One dashboard.\n\nhttps://athlynx.ai\n\n#ATHLYNX #RecruitingAnalytics #SportsData #CoachingEdge", "link": "https://athlynx.ai"},
    {"text": "⚾ DIAMOND GRIND BASEBALL.\n\nFrom Little League to the pros — ATHLYNX tracks every pitch, every at-bat, and every recruiting opportunity.\n\nGet started 👉 https://athlynx.ai/diamond-grind\n\n#DiamondGrind #BaseballNIL #ATHLYNX #CollegiateBaseball", "link": "https://athlynx.ai/diamond-grind"},
    {"text": "🏈 WARRIORS PLAYBOOK — FOOTBALL DOMINANCE.\n\nATHLYNX's football platform gives players the edge in recruiting, film study, and NIL deals.\n\nOwn the field 👉 https://athlynx.ai/warriors-playbook\n\n#WarriorsPlaybook #FootballNIL #ATHLYNX #CollegiateFootball", "link": "https://athlynx.ai/warriors-playbook"},
    {"text": "💡 BUILT FOR LESS THAN $145,000.\n\nATHLYNX AI — 142 pages. 75,662 lines of code. 34 database tables. Dual AI engines.\n\nA traditional team would charge $2,074,000. We built it for $145K.\n\nPre-Seed round open → cdozier14@athlynx.ai\n\n#ATHLYNX #SportsTech #Startup #NIL", "link": "https://athlynx.ai"},
    {"text": "🎯 SIGNING DAY IS EVERY DAY ON ATHLYNX.\n\nTrack your letter of intent, manage your commitments, and celebrate your signing day with the ATHLYNX community.\n\nhttps://athlynx.ai\n\n#SigningDay #CollegeRecruiting #ATHLYNX #NIL", "link": "https://athlynx.ai"},
    {"text": "🧠 YOUR AI TRAINER KNOWS YOU.\n\nATHLYNX's personal AI Trainer Bot remembers every conversation, every workout, and every goal.\n\nStart training smarter 👉 https://athlynx.ai\n\n#AITrainer #AthletePerformance #ATHLYNX #SportsAI", "link": "https://athlynx.ai"},
    {"text": "🥇 NIL IS NOT A TREND — IT'S YOUR CAREER.\n\nATHLYNX's NIL Vault secures your deals, tracks your earnings, and grows your brand.\n\nProtect your NIL 👉 https://athlynx.ai/nil-vault\n\n#NILVault #AthleteMarketing #ATHLYNX #CollegiateAthletes", "link": "https://athlynx.ai/nil-vault"},
    {"text": "🏋️ ELITE ATHLETES USE ELITE TOOLS.\n\nATHLYNX's AI-powered platform gives you the same analytics edge that pro teams use — for free.\n\nJoin the elite 👉 https://athlynx.ai\n\n#EliteAthletes #SportsAI #ATHLYNX #NIL", "link": "https://athlynx.ai"},
    {"text": "📱 YOUR ENTIRE ATHLETIC CAREER IN ONE APP.\n\nStats. Recruiting. NIL deals. Scheduling. Community. All on ATHLYNX.\n\nDownload now 👉 https://athlynx.ai\n\n#ATHLYNX #AthleteApp #NIL #SportsAI", "link": "https://athlynx.ai"},
    {"text": "🤝 BRANDS WANT TO WORK WITH YOU.\n\nATHLYNX's AI matches athletes with brands based on sport, audience, and values — not just follower count.\n\nFind your brand deal 👉 https://athlynx.ai\n\n#NILDeals #BrandPartnerships #ATHLYNX #AthleteMarketing", "link": "https://athlynx.ai"},
    {"text": "🌟 CHAD DOZIER SR. — FOUNDER & CEO.\n\nBuilt ATHLYNX AI from the ground up to give every athlete — regardless of school size — a fair shot at NIL deals and recruiting exposure.\n\nJoin the mission 👉 https://athlynx.ai\n\n#ATHLYNX #Founder #SportsTech #NIL", "link": "https://athlynx.ai"},
    {"text": "🏟️ PRO TEAMS — POWERED BY ATHLYNX.\n\nScout smarter. Recruit faster. Build your roster with AI-driven athlete intelligence.\n\nPro Teams platform 👉 https://athlynx.ai/pro-teams\n\n#ProTeams #SportsScouting #ATHLYNX #AIRecruiting", "link": "https://athlynx.ai/pro-teams"},
    {"text": "💼 DOZIER HOLDINGS GROUP — THE EMPIRE BEHIND ATHLYNX.\n\nDHG is the parent company powering AthlynX AI, Diamond Grind Baseball, Warriors Playbook, and ConCreator™.\n\nLearn more 👉 https://athlynx.ai/dhg\n\n#DozierHoldingsGroup #DHG #SportsTech #NIL", "link": "https://athlynx.ai/dhg"},
    {"text": "⚡ CONCREATOR™ — AI CREDITS FOR BUSINESS.\n\nB2B AI intelligence platform built by Dozier Holdings Group. Pulse, Insight, Command, and Enterprise tiers available.\n\nGet started 👉 https://athlynx.ai/softmor\n\n#ConCreator #B2BAI #DozierHoldingsGroup #AICredits", "link": "https://athlynx.ai/softmor"},
    {"text": "🙏 FAITH FUELS THE GRIND.\n\nATHLYNX's Faith section is for athletes who compete with purpose and train with conviction.\n\nIron Sharpens Iron — Proverbs 27:17\n\nhttps://athlynx.ai/faith\n\n#Faith #ATHLYNX #IronSharpensIron #AthleteLife", "link": "https://athlynx.ai/faith"},
    {"text": "📣 THE NIL PORTAL IS OPEN.\n\nATHLYNX's NIL Portal connects athletes directly to brand deals, sponsorships, and earning opportunities.\n\nClaim your NIL 👉 https://athlynx.ai/nil-portal\n\n#NILPortal #ATHLYNX #AthleteMarketing #GetPaid", "link": "https://athlynx.ai/nil-portal"},
    {"text": "🔄 TRANSFER PORTAL SEASON IS YEAR-ROUND.\n\nATHLYNX tracks every transfer, every opportunity, and every school that's looking for your position.\n\nExplore the portal 👉 https://athlynx.ai/transfer-portal\n\n#TransferPortal #CollegeRecruiting #ATHLYNX #NIL", "link": "https://athlynx.ai/transfer-portal"},
    {"text": "🎓 RECRUITING STARTS EARLIER THAN YOU THINK.\n\nATHLYNX helps student-athletes build their recruiting profile from day one — so coaches find them before the competition does.\n\nhttps://athlynx.ai\n\n#CollegeRecruiting #ATHLYNX #StudentAthlete #NIL", "link": "https://athlynx.ai"},
    {"text": "🛒 THE ATHLYNX STORE IS LIVE.\n\nGear up with official ATHLYNX merchandise — and rep the platform that's changing athlete careers.\n\nShop now 👉 https://athlynx.ai/store\n\n#ATHLYNXStore #AthleteGear #NIL #SportsMerch", "link": "https://athlynx.ai/store"},
    {"text": "📅 ELITE EVENTS — WHERE ATHLETES GET DISCOVERED.\n\nATHLYNX's Elite Events platform connects athletes to showcases, combines, and recruiting camps.\n\nFind your event 👉 https://athlynx.ai/elite-events\n\n#EliteEvents #AthleteShowcase #ATHLYNX #Recruiting", "link": "https://athlynx.ai/elite-events"},
    {"text": "🔥 X-FACTOR FEED — ATHLETE CULTURE LIVES HERE.\n\nThe ATHLYNX X-Factor Feed is where athletes share wins, highlight reels, and real talk about the grind.\n\nJoin the conversation 👉 https://athlynx.ai/x-factor\n\n#XFactor #ATHLYNX #AthleteLife #NIL", "link": "https://athlynx.ai/x-factor"},
]

# ─────────────────────────────────────────────
# ROTATION LOGIC (mirrors TypeScript exactly)
# ─────────────────────────────────────────────

def get_day_of_year():
    now = datetime.now()
    start = datetime(now.year, 1, 1)
    return (now - start).days  # 0-indexed like JS Math.floor

def get_hour_slot():
    hour = datetime.now(timezone.utc).hour
    if hour < 14:
        return 0   # 8am CST
    elif hour < 18:
        return 1   # 12pm CST
    else:
        return 2   # 6pm CST

def get_post_index(channel_offset):
    day = get_day_of_year()
    slot = get_hour_slot()
    num_channels = len(TEXT_CHANNELS_ORDERED)
    num_slots = 3
    return (day * num_slots * num_channels + slot * num_channels + channel_offset) % len(POST_LIBRARY)

def get_image_index(channel_offset):
    day = get_day_of_year()
    slot = get_hour_slot()
    num_channels = len(TEXT_CHANNELS_ORDERED)
    num_slots = 3
    stride = 7
    return (day * num_slots * num_channels * stride + slot * num_channels + channel_offset * stride) % len(IMAGE_LIBRARY)

# ─────────────────────────────────────────────
# BUFFER API — Correct mutation per Master Reference
# ─────────────────────────────────────────────

# Buffer mutation — channelId inlined to avoid ChannelId! scalar type mismatch
def make_buffer_mutation(channel_id, text):
    # Escape text for GraphQL string
    escaped = text.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n')
    return f'''
    mutation {{
      createPost(input: {{
        channelId: "{channel_id}"
        text: "{escaped}"
        schedulingType: automatic
        mode: shareNow
      }}) {{
        __typename
      }}
    }}
    '''

def post_to_buffer(channel_id, channel_name, text, image_url):
    try:
        mutation = make_buffer_mutation(channel_id, text)
        response = requests.post(
            "https://api.buffer.com/graphql",
            headers={
                "Authorization": f"Bearer {BUFFER_TOKEN}",
                "Content-Type": "application/json",
            },
            json={"query": mutation},
            timeout=30,
        )
        result = response.json()
        typename = result.get("data", {}).get("createPost", {}).get("__typename", "")
        if typename == "PostActionSuccess":
            print(f"  ✅ {channel_name}: PostActionSuccess | Image: {image_url}")
            return True, "PostActionSuccess"
        else:
            errors = result.get("errors") or result.get("data")
            print(f"  ❌ {channel_name}: {json.dumps(errors)}")
            return False, json.dumps(errors)
    except Exception as e:
        print(f"  ❌ {channel_name} ERROR: {e}")
        return False, str(e)

# ─────────────────────────────────────────────
# MAIN RUNNER
# ─────────────────────────────────────────────

def run():
    now = datetime.now()
    day = get_day_of_year()
    slot = get_hour_slot()
    slot_label = ["8am CST", "12pm CST", "6pm CST"][slot]

    print(f"\n{'='*60}")
    print(f"ATHLYNX Social Post Runner")
    print(f"Date: {now.strftime('%A, %B %d, %Y')} | Day of Year: {day} | Slot: {slot} ({slot_label})")
    print(f"{'='*60}\n")

    results = []

    # Post to each Buffer channel
    for channel in TEXT_CHANNELS_ORDERED:
        post_idx = get_post_index(channel["offset"])
        img_idx = get_image_index(channel["offset"])
        post = POST_LIBRARY[post_idx]
        image = IMAGE_LIBRARY[img_idx]

        print(f"[{channel['name']}] Post #{post_idx} | Image #{img_idx}")
        print(f"  Text preview: {post['text'][:80]}...")
        success, status = post_to_buffer(channel["id"], channel["name"], post["text"], image)
        results.append({
            "channel": channel["name"],
            "post_index": post_idx,
            "image_index": img_idx,
            "image_url": image,
            "text_preview": post["text"][:100],
            "success": success,
            "status": status,
        })
        print()

    print(f"\n{'='*60}")
    print("SUMMARY")
    print(f"{'='*60}")
    for r in results:
        icon = "✅" if r["success"] else "❌"
        print(f"  {icon} {r['channel']} → Post #{r['post_index']} | Image #{r['image_index']} | {r['status']}")

    return results

if __name__ == "__main__":
    run()
