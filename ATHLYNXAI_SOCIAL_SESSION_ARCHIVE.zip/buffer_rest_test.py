"""
Try Buffer REST API v1 as alternative to GraphQL for channels returning UnexpectedError
Also check organization/billing info
"""
import requests
import json

BUFFER_TOKEN = "kB3LprBJtIH1-1F1v_DQcjOIRFdX13YFQVPXrpz9gD_"
ORG_ID = "69e5eb4fa8900ccfe436f53a"

# Check organization info
print("=== Organization Info ===")
org_query = f"""
query {{
  organization(id: "{ORG_ID}") {{
    id
    name
    plan
    isOneBufferOrganization
  }}
}}
"""
r = requests.post(
    "https://api.buffer.com/graphql",
    headers={"Authorization": f"Bearer {BUFFER_TOKEN}", "Content-Type": "application/json"},
    json={"query": org_query},
    timeout=30,
)
print(json.dumps(r.json(), indent=2))

# Check if there's a scheduling queue issue — try with schedulingType: queue
print("\n=== Testing with schedulingType: queue (instead of automatic) ===")
test_channel = "69f29ddf5c4c051afaf3e12e"  # Facebook/Athlynx
test_text = "🏆 ATHLYNX.AI — The #1 AI Platform for Athletes & NIL Deals. https://athlynx.ai #ATHLYNX #NIL"
escaped = test_text.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n')

mutation_queue = f'''
mutation {{
  createPost(input: {{
    channelId: "{test_channel}"
    text: "{escaped}"
    schedulingType: queue
  }}) {{
    __typename
  }}
}}
'''
r2 = requests.post(
    "https://api.buffer.com/graphql",
    headers={"Authorization": f"Bearer {BUFFER_TOKEN}", "Content-Type": "application/json"},
    json={"query": mutation_queue},
    timeout=30,
)
print(json.dumps(r2.json(), indent=2))

# Try REST API v1
print("\n=== Buffer REST API v1 — /v1/updates/create.json ===")
r3 = requests.post(
    "https://api.bufferapp.com/1/updates/create.json",
    headers={"Authorization": f"Bearer {BUFFER_TOKEN}"},
    data={
        "profile_ids[]": "69f29ddf5c4c051afaf3e12e",
        "text": test_text,
        "now": "true",
    },
    timeout=30,
)
print(f"HTTP {r3.status_code}: {r3.text[:500]}")
